export interface ProgressProps {
  primaryStep?: number;
  secondaryStep?: number;
  showProgressBunny?: boolean;
}
